"""
===============================================================================
  TRANSIT DISRUPTION DASHBOARD — STREAMLIT FRONTEND  v2.1
  7-Layer Architecture · Layer 7 (Deployment Interface)
===============================================================================
  Pages
  -----
  Overview    → KPI row, route table, event log, alert donut, system status
  Live Map    → Folium vehicle map (live → sample), delay hotspots
  Predictions → RF/XGB 30-min forecasts, SHAP TreeExplainer panel
  Analytics   → 24-h trend, budget vs actuals, period KPIs

  All data fetched from FastAPI backend (http://backend:8000).
  Every fetch has a sample-data fallback so the UI never crashes.
  Auto-refresh uses st_autorefresh when installed, else a manual button.
===============================================================================
"""

from __future__ import annotations

import os
import time
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import requests
import streamlit as st

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

# ══════════════════════════════════════════════════════════════════════════════
# CONFIG
# ══════════════════════════════════════════════════════════════════════════════
API_URL          = os.getenv("API_BASE_URL",   "http://backend:8000")
REFRESH_INTERVAL = int(os.getenv("REFRESH_INTERVAL", "30"))

st.set_page_config(
    page_title="TransitOS — NL Operations",
    layout="wide",
    initial_sidebar_state="expanded",
    page_icon="🚌",
)

# ── optional deps ─────────────────────────────────────────────────────────────
try:
    import folium
    from streamlit_folium import st_folium
    FOLIUM_OK = True
except ImportError:
    FOLIUM_OK = False

try:
    from streamlit_autorefresh import st_autorefresh  # type: ignore
    AUTOREFRESH_OK = True
except ImportError:
    AUTOREFRESH_OK = False

# ══════════════════════════════════════════════════════════════════════════════
# CSS / TYPOGRAPHY
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500&family=Syne:wght@700;800&display=swap');

html, body, [class*="css"] { font-family: 'IBM Plex Mono', monospace !important; }
.stApp { background: #ffffff; }
#MainMenu, footer, header { visibility: hidden; }
.block-container { padding-top: 0.4rem !important; max-width: 100% !important; }

/* ── topbar ── */
.topbar {
    display:flex; align-items:center; justify-content:space-between;
    padding:10px 20px; background:#f7f7f5;
    border-bottom:.5px solid #ddd; margin-bottom:.8rem;
}
.logo { font-family:'Syne',sans-serif; font-weight:800;
         font-size:20px; letter-spacing:.04em; }
.logo span { color:#1A5FA0; }
.live-dot { display:inline-block; width:8px; height:8px; border-radius:50%;
             background:#2A7A4A; animation:pulse 1.8s ease-in-out infinite; }
@keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.3} }

/* ── KPI cards ── */
.kpi-card {
    background:#f7f7f5; border:.5px solid #e0e0dc; border-radius:4px;
    padding:14px 16px; border-top:3px solid transparent;
}
.kpi-card.green { border-top-color:#2A7A4A; }
.kpi-card.amber { border-top-color:#B07010; }
.kpi-card.red   { border-top-color:#C84040; }
.kpi-card.blue  { border-top-color:#1A5FA0; }
.kpi-label { font-size:9px; letter-spacing:.14em; text-transform:uppercase;
              color:#888; margin-bottom:6px; }
.kpi-val   { font-family:'Syne',sans-serif; font-weight:800;
              font-size:26px; line-height:1; margin-bottom:2px; }
.kpi-val.green { color:#2A7A4A; }
.kpi-val.amber { color:#B07010; }
.kpi-val.red   { color:#C84040; }
.kpi-val.blue  { color:#1A5FA0; }
.kpi-sub { font-size:10px; color:#888; }

/* ── badges ── */
.badge { display:inline-block; padding:2px 8px; border-radius:4px;
          font-size:10px; font-weight:500; border:.5px solid; }
.badge-crit { background:#FCEBEB; color:#C84040; border-color:#F09595; }
.badge-warn { background:#FAEEDA; color:#B07010; border-color:#FAC775; }
.badge-ok   { background:#EAF3DE; color:#2A7A4A; border-color:#C0DD97; }
.badge-info { background:#E6F1FB; color:#1A5FA0; border-color:#B5D4F4; }

/* ── section header ── */
.sh { font-size:9px; letter-spacing:.14em; text-transform:uppercase; color:#888;
       border-bottom:.5px solid #ddd; padding-bottom:5px; margin-bottom:10px; }

/* ── sidebar ── */
[data-testid="stSidebar"] { background:#f7f7f5 !important; border-right:.5px solid #ddd; }

/* ── pred card ── */
.pred-card {
    display:flex; align-items:center; gap:12px; padding:12px;
    border:.5px solid #e8e8e4; border-radius:4px; margin-bottom:8px;
}
</style>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# API HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _get(path: str, timeout: int = 8) -> Optional[Dict]:
    try:
        r = requests.get(f"{API_URL}{path}", timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as exc:
        logger.warning(f"GET {path} → {exc}")
        return None


def _post(path: str, payload: Dict, timeout: int = 10) -> Optional[Dict]:
    try:
        r = requests.post(f"{API_URL}{path}", json=payload, timeout=timeout)
        r.raise_for_status()
        return r.json()
    except Exception as exc:
        logger.warning(f"POST {path} → {exc}")
        return None


def _api_online() -> bool:
    d = _get("/health", timeout=3)
    return bool(d and d.get("status") == "ok")


def _active_model() -> str:
    d = _get("/model/info", timeout=3)
    return d.get("active", "simulation") if d else "simulation"


# ══════════════════════════════════════════════════════════════════════════════
# SAMPLE / FALLBACK DATA
# ══════════════════════════════════════════════════════════════════════════════

def _fallback_routes() -> List[Dict]:
    return [
        {"id":"R-01","name":"Amsterdam C → Schiphol",  "status":"crit",  "delay":18.4,"bunch":0.82,"throughput":340,"pred":89},
        {"id":"R-04","name":"Utrecht → Den Haag",       "status":"crit",  "delay":12.1,"bunch":0.67,"throughput":210,"pred":74},
        {"id":"R-07","name":"Rotterdam → Dordrecht",    "status":"delay", "delay":5.8, "bunch":0.44,"throughput":185,"pred":47},
        {"id":"R-12","name":"Eindhoven → Tilburg",      "status":"delay", "delay":3.2, "bunch":0.31,"throughput":150,"pred":29},
        {"id":"R-15","name":"Haarlem → Leiden",         "status":"ok",    "delay":0.9, "bunch":0.12,"throughput":220,"pred":11},
        {"id":"R-22","name":"Delft → Rotterdam C",      "status":"ok",    "delay":1.1, "bunch":0.18,"throughput":190,"pred":8},
        {"id":"R-03","name":"Arnhem → Nijmegen",        "status":"delay", "delay":4.4, "bunch":0.38,"throughput":120,"pred":35},
        {"id":"R-09","name":"Breda → Tilburg",          "status":"ok",    "delay":0.4, "bunch":0.08,"throughput":95, "pred":6},
    ]


def _fallback_metrics() -> Dict:
    return {
        "on_time_pct":88.2, "active_disruptions":12, "avg_delay_min":8.2,
        "prediction_f1":0.87, "service_delivered_pct":96.5,
        "data_quality_score":94.1, "inference_latency_ms":145,
        "throughput_veh_hr":1240, "model_active":"simulation",
    }


def _fallback_alerts() -> List[Dict]:
    return [
        {"time":"now", "msg":"R-01 speed drop — 22 km/h",               "sev":"crit"},
        {"time":"2m",  "msg":"R-04 bunching alert — 3 vehicles clustered","sev":"crit"},
        {"time":"7m",  "msg":"R-07 schedule slip — +5.8 min avg",        "sev":"warn"},
        {"time":"12m", "msg":"RF model: R-01 SEVERE (89% confidence)",   "sev":"info"},
        {"time":"18m", "msg":"R-12 headway variance elevated",           "sev":"warn"},
        {"time":"24m", "msg":"GTFS-RT feed reconnected",                 "sev":"info"},
        {"time":"31m", "msg":"R-15 back on-time",                        "sev":"ok"},
    ]


def _fallback_vehicles(n: int = 80) -> pd.DataFrame:
    seed = int(time.time()) // 30
    rng  = np.random.default_rng(seed)
    routes = ["R-01","R-03","R-04","R-07","R-09","R-12","R-15","R-22"]
    return pd.DataFrame({
        "vehicle_id": [f"NL-{1000+i}" for i in range(n)],
        "route_id":   rng.choice(routes, n),
        "latitude":   rng.uniform(51.88, 52.42, n).round(5),
        "longitude":  rng.uniform(4.18,  5.18,  n).round(5),
        "speed":      rng.uniform(0, 82, n).round(1),
        "bearing":    rng.integers(0, 360, n),
    })


def _fallback_shap() -> Dict[str, float]:
    return {
        "bunching_index":0.42,"delay_mean_15m":0.35,"speed_drop_ratio":0.31,
        "on_time_pct":0.28,"delay_mean_5m":0.25,"speed_mean":0.22,
        "delay_mean_30m":0.20,"headway_variance":0.18,"fleet_utilization":0.15,
        "alert_nlp_score":0.12,"speed_std":0.10,"alert_count":0.08,
    }


# ══════════════════════════════════════════════════════════════════════════════
# CACHED DATA FETCHERS
# ══════════════════════════════════════════════════════════════════════════════

@st.cache_data(ttl=REFRESH_INTERVAL)
def fetch_metrics() -> Dict:
    return _get("/metrics") or _fallback_metrics()


@st.cache_data(ttl=REFRESH_INTERVAL)
def fetch_routes() -> List[Dict]:
    data = _get("/routes")
    routes = data.get("routes", []) if data else []
    if not routes:
        return _fallback_routes()

    # Attach prediction probabilities from the batch endpoint
    payload = {"routes": [
        {"route_id": r["id"],
         "bunching_index":  r.get("bunch", 0.2),
         "delay_mean_15m":  r.get("delay", 0) * 60,
         "speed_mean":      max(5.0, 35 - r.get("delay", 0) * 0.8)}
        for r in routes
    ]}
    pred_data = _post("/predict/batch", payload)
    if pred_data:
        pred_map = {
            p["route_id"]: round(p["confidence"] * 100, 1)
            for p in pred_data.get("results", [])
        }
        for r in routes:
            r["pred"] = pred_map.get(r["id"], 0.0)
    else:
        for r in routes:
            r.setdefault("pred", 0.0)
    return routes


@st.cache_data(ttl=REFRESH_INTERVAL)
def fetch_alerts() -> List[Dict]:
    data = _get("/alerts")
    return data.get("alerts", _fallback_alerts()) if data else _fallback_alerts()


@st.cache_data(ttl=REFRESH_INTERVAL)
def fetch_vehicles() -> pd.DataFrame:
    data = _get("/feed")
    if data and data.get("vehicles"):
        try:
            return pd.DataFrame(data["vehicles"])
        except Exception:
            pass
    return _fallback_vehicles()


@st.cache_data(ttl=60)
def fetch_shap(route_id: str) -> Dict[str, float]:
    data = _get(f"/shap/{route_id}")
    return data.get("contributions", _fallback_shap()) if data else _fallback_shap()


# ══════════════════════════════════════════════════════════════════════════════
# COLOUR HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _delay_color(d: float) -> str:
    return "#C84040" if d > 8 else "#B07010" if d > 3 else "#2A7A4A"

def _prob_color(p: float) -> str:
    return "#C84040" if p > 70 else "#B07010" if p > 40 else "#2A7A4A"

ROUTE_COLORS = {
    "R-01":"#C84040","R-04":"#C84040","R-07":"#B07010",
    "R-12":"#B07010","R-15":"#2A7A4A","R-22":"#2A7A4A",
    "R-03":"#B07010","R-09":"#1A5FA0",
}

STATUS_HTML = {
    "crit":  '<span class="badge badge-crit">Critical</span>',
    "delay": '<span class="badge badge-warn">Delayed</span>',
    "ok":    '<span class="badge badge-ok">On-time</span>',
}

SEV_COLOR = {"crit":"#C84040","warn":"#B07010","info":"#1A5FA0","ok":"#2A7A4A"}


# ══════════════════════════════════════════════════════════════════════════════
# CHART BUILDERS
# ══════════════════════════════════════════════════════════════════════════════

_CHART_FONT = dict(family="IBM Plex Mono", size=11)
_TRANSPARENT = "rgba(0,0,0,0)"


def _base_layout(**kwargs) -> Dict:
    return dict(
        paper_bgcolor=_TRANSPARENT, plot_bgcolor=_TRANSPARENT,
        font=_CHART_FONT, showlegend=False, margin=dict(t=4,b=4,l=4,r=4),
        **kwargs,
    )


def fig_sparkline(data: List[int]) -> go.Figure:
    colors = ["#C84040" if v > 25 else "#B07010" if v > 15 else "#1A5FA0" for v in data]
    fig = go.Figure(go.Bar(x=list(range(len(data))), y=data,
                           marker_color=colors, marker_line_width=0))
    fig.update_layout(**_base_layout(height=72),
                      xaxis=dict(visible=False), yaxis=dict(visible=False))
    return fig


def fig_donut(data: Dict[str, int]) -> go.Figure:
    fig = go.Figure(go.Pie(
        labels=list(data.keys()), values=list(data.values()), hole=0.65,
        marker=dict(colors=["#E24B4A","#BA7517","#185FA5","#3B6D11"],
                    line=dict(color="white", width=1)),
        textinfo="none",
    ))
    fig.update_layout(**_base_layout(height=130))
    return fig


def fig_delay_bars(routes: List[Dict]) -> go.Figure:
    df = pd.DataFrame(routes).sort_values("delay", ascending=True)
    fig = go.Figure(go.Bar(
        y=df["id"], x=df["delay"], orientation="h",
        marker_color=[_delay_color(d) for d in df["delay"]], marker_line_width=0,
        text=[f"{d:.1f} min" for d in df["delay"]], textposition="outside",
    ))
    fig.update_layout(**_base_layout(height=230),
                      xaxis=dict(showgrid=False, showticklabels=False),
                      yaxis=dict(tickfont=_CHART_FONT))
    return fig


def fig_shap(contributions: Dict[str, float]) -> go.Figure:
    items  = sorted(contributions.items(), key=lambda x: x[1], reverse=True)[:10]
    names, vals = zip(*items)
    colors = ["#C84040" if v > 0.3 else "#B07010" if v > 0.15 else "#1A5FA0" for v in vals]
    fig = go.Figure(go.Bar(
        y=list(names), x=list(vals), orientation="h",
        marker_color=colors, marker_line_width=0,
        text=[f"{v:.4f}" for v in vals], textposition="outside",
    ))
    fig.update_layout(**_base_layout(height=280),
                      xaxis=dict(showgrid=False, showticklabels=False),
                      yaxis=dict(tickfont=_CHART_FONT, autorange="reversed"))
    return fig


def fig_trend(hours, values) -> go.Figure:
    fig = go.Figure(go.Scatter(
        x=hours, y=values, mode="lines",
        line=dict(color="#1A5FA0", width=2),
        fill="tozeroy", fillcolor="rgba(26,95,160,.06)",
    ))
    fig.update_layout(**_base_layout(height=190, showlegend=False),
                      xaxis=dict(showgrid=False), yaxis=dict(showgrid=False))
    return fig


def fig_vehicle_map_plotly(df: pd.DataFrame) -> go.Figure:
    df = df.dropna(subset=["latitude","longitude"])
    if df.empty:
        fig = go.Figure()
        fig.add_annotation(text="No position data", showarrow=False,
                           font=dict(color="#888", size=13))
        fig.update_layout(height=320, paper_bgcolor=_TRANSPARENT)
        return fig
    fig = px.scatter_mapbox(
        df, lat="latitude", lon="longitude", color="route_id",
        color_discrete_map=ROUTE_COLORS, zoom=9,
        center={"lat": float(df["latitude"].mean()),
                "lon": float(df["longitude"].mean())},
        hover_name="vehicle_id" if "vehicle_id" in df.columns else None,
        hover_data={"speed": True} if "speed" in df.columns else {},
    )
    fig.update_layout(
        mapbox_style="carto-positron",
        **_base_layout(height=340, showlegend=True),
        legend=dict(orientation="h", y=1.02, font=dict(size=10)),
    )
    return fig


def _folium_map(df: pd.DataFrame) -> "folium.Map":
    lat0 = float(df["latitude"].mean())  if not df.empty else 52.1
    lon0 = float(df["longitude"].mean()) if not df.empty else 4.7
    m = folium.Map(location=[lat0, lon0], zoom_start=10,
                   tiles="CartoDB positron")
    for _, row in df.iterrows():
        if pd.isna(row.get("latitude")) or pd.isna(row.get("longitude")):
            continue
        color = ROUTE_COLORS.get(row.get("route_id",""), "gray")
        spd   = row.get("speed", 0) or 0
        folium.CircleMarker(
            location=[row["latitude"], row["longitude"]],
            radius=6, color=color, fill=True,
            fill_color=color, fill_opacity=0.75,
            tooltip=f"{row.get('vehicle_id','?')} · {row.get('route_id','?')} · {spd:.0f} km/h",
        ).add_to(m)
    return m


# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════

def render_sidebar(api_ok: bool, model_name: str, metrics: Dict) -> Dict:
    with st.sidebar:
        st.markdown(
            '<div class="logo" style="padding:10px 0 14px">TRANSIT<span>OS</span></div>'
            '<div style="font-size:10px;color:#888;margin-top:-10px;margin-bottom:14px">'
            'NL · OPERATIONS CENTER</div>',
            unsafe_allow_html=True,
        )

        # API status
        col_dot, col_txt = st.columns([1, 5])
        with col_dot:
            st.markdown('<span class="live-dot"></span>', unsafe_allow_html=True)
        with col_txt:
            color = "#2A7A4A" if api_ok else "#C84040"
            label = "API online" if api_ok else "API offline — sample data"
            st.markdown(f'<span style="font-size:11px;color:{color}">{label}</span>',
                        unsafe_allow_html=True)

        st.markdown(f'<div style="font-size:10px;color:#888;margin:4px 0 12px">'
                    f'{datetime.now().strftime("%H:%M:%S UTC")}</div>',
                    unsafe_allow_html=True)

        st.markdown("---")
        st.markdown('<div class="sh">Navigation</div>', unsafe_allow_html=True)
        page = st.radio("Page",
                        ["Overview", "Live Map", "Predictions", "Analytics"],
                        label_visibility="collapsed")

        st.markdown("---")
        st.markdown('<div class="sh">Filters</div>', unsafe_allow_html=True)
        sev_filter = st.multiselect(
            "Severity",
            ["Critical", "Delayed", "On-time"],
            default=["Critical", "Delayed", "On-time"],
        )
        search = st.text_input("Search route", placeholder="R-01, Amsterdam…")

        st.markdown("---")
        st.markdown('<div class="sh">Auto-refresh</div>', unsafe_allow_html=True)
        auto_refresh = st.checkbox(f"Enable ({REFRESH_INTERVAL}s)", value=False)
        if auto_refresh:
            if AUTOREFRESH_OK:
                st_autorefresh(interval=REFRESH_INTERVAL * 1000, key="ar")
            else:
                st.caption("Install streamlit-autorefresh for true auto-refresh.")
                if st.button("↺ Refresh now"):
                    st.cache_data.clear()
                    st.rerun()

        st.markdown("---")
        st.markdown('<div class="sh">Model</div>', unsafe_allow_html=True)
        st.markdown(
            f'<div style="font-size:11px;line-height:1.9">'
            f'<span style="color:#888">Active:</span> {model_name}<br>'
            f'<span style="color:#888">F1 score:</span> {metrics.get("prediction_f1",0.87):.2f}<br>'
            f'<span style="color:#888">Latency P95:</span> {metrics.get("inference_latency_ms",145)} ms<br>'
            f'<span style="color:#888">Leakage ctrl:</span> <span style="color:#2A7A4A">Active</span>'
            f'</div>',
            unsafe_allow_html=True,
        )

        st.markdown("")
        if st.button("↺ Clear cache"):
            st.cache_data.clear()
            st.rerun()

        # Hot-reload model button
        if st.button("⟳ Reload model"):
            resp = _post("/model/reload", {})
            if resp:
                st.success("Reload scheduled — check /model/info in a moment.")
            else:
                st.warning("Backend unreachable.")

    return {"page": page, "sev_filter": sev_filter,
            "search": search, "auto_refresh": auto_refresh}


# ══════════════════════════════════════════════════════════════════════════════
# SHARED TOPBAR + KPI ROW
# ══════════════════════════════════════════════════════════════════════════════

def render_topbar(api_ok: bool, model_name: str):
    api_color = "#2A7A4A" if api_ok else "#C84040"
    api_label = "● API online" if api_ok else "● API offline"
    st.markdown(f"""
    <div class="topbar">
        <div style="display:flex;align-items:center;gap:12px">
            <span class="live-dot"></span>
            <span class="logo">TRANSIT<span>OS</span></span>
            <span style="font-size:10px;color:#888">NL · OPERATIONS CENTER</span>
        </div>
        <div style="display:flex;align-items:center;gap:20px;font-size:10px;color:#888">
            <span>Model: {model_name}</span>
            <span style="color:{api_color}">{api_label}</span>
            <span style="font-size:13px;font-weight:500;color:#333">
                {datetime.now().strftime("%H:%M:%S")}
            </span>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_kpi_row(m: Dict):
    kpis = [
        ("On-time perf.",    f"{m.get('on_time_pct',88.2):.1f}%",          "↓ 1.4% vs yesterday",  "green"),
        ("Active disruptions",str(m.get("active_disruptions",12)),          "3 critical · 9 minor", "amber"),
        ("Avg system delay", f"{m.get('avg_delay_min',8.2):.1f} min",       "Target < 2 min",       "red"),
        ("Model F1",         f"{m.get('prediction_f1',0.87):.2f}",
         f"Latency {m.get('inference_latency_ms',145)} ms",                                         "blue"),
        ("Service delivered",f"{m.get('service_delivered_pct',96.5):.1f}%", "↑ 0.3% vs target",    "green"),
    ]
    for col, (lbl, val, sub, color) in zip(st.columns(5), kpis):
        with col:
            st.markdown(f"""
            <div class="kpi-card {color}">
                <div class="kpi-label">{lbl}</div>
                <div class="kpi-val {color}">{val}</div>
                <div class="kpi-sub">{sub}</div>
            </div>""", unsafe_allow_html=True)
    st.markdown("<div style='margin-bottom:.4rem'></div>", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: OVERVIEW
# ══════════════════════════════════════════════════════════════════════════════

def page_overview(routes: List[Dict], alerts: List[Dict], metrics: Dict, opts: Dict):
    sev_map    = {"Critical":"crit","Delayed":"delay","On-time":"ok"}
    allowed    = {sev_map[s] for s in opts.get("sev_filter", list(sev_map.keys()))}
    q          = opts.get("search","").lower()
    filtered   = [r for r in routes
                  if r["status"] in allowed
                  and (not q or q in r["id"].lower() or q in r["name"].lower())]

    col_main, col_side = st.columns([3, 1])

    # ── left ──────────────────────────────────────────────────────────────────
    with col_main:
        tab_routes, tab_events, tab_charts = st.tabs(["Routes", "Event log", "Charts"])

        with tab_routes:
            if filtered:
                hcols = st.columns([1.1, 2.2, 1, 1.2, 1.2, 1])
                for h, c in zip(["Route","Name","Status","Delay","Bunching","Pred."], hcols):
                    c.markdown(
                        f'<div style="font-size:9px;letter-spacing:.1em;'
                        f'text-transform:uppercase;color:#888">{h}</div>',
                        unsafe_allow_html=True,
                    )
                st.markdown('<div style="border-top:.5px solid #ddd;margin-bottom:4px"></div>',
                            unsafe_allow_html=True)
                for r in filtered:
                    c1,c2,c3,c4,c5,c6 = st.columns([1.1,2.2,1,1.2,1.2,1])
                    c1.markdown(f'<div style="font-weight:500;font-size:12px">{r["id"]}</div>',
                                unsafe_allow_html=True)
                    c2.markdown(f'<div style="font-size:11px;color:#555">{r["name"]}</div>',
                                unsafe_allow_html=True)
                    c3.markdown(STATUS_HTML.get(r["status"],""), unsafe_allow_html=True)
                    d = r.get("delay", 0)
                    c4.markdown(
                        f'<div style="font-family:Syne,sans-serif;font-weight:800;'
                        f'font-size:15px;color:{_delay_color(d)}">{d:.1f} min</div>',
                        unsafe_allow_html=True,
                    )
                    b = r.get("bunch", 0)
                    c5.markdown(f"""
                        <div style="font-size:11px;margin-bottom:3px">{b*100:.0f}%</div>
                        <div style="height:3px;background:#eee;border-radius:2px">
                          <div style="height:3px;width:{b*100:.0f}%;border-radius:2px;
                                      background:{_delay_color(b*10)}"></div>
                        </div>""", unsafe_allow_html=True)
                    p = r.get("pred", 0)
                    c6.markdown(
                        f'<div style="font-family:Syne,sans-serif;font-weight:800;'
                        f'font-size:15px;color:{_prob_color(p)}">{p:.0f}%</div>',
                        unsafe_allow_html=True,
                    )
                    st.markdown('<div style="border-top:.5px solid #f0f0ee;margin:4px 0"></div>',
                                unsafe_allow_html=True)
            else:
                st.info("No routes match the current filters.")

        with tab_events:
            for ev in alerts:
                dot_color = SEV_COLOR.get(ev.get("sev","ok"), "#888")
                st.markdown(f"""
                <div style="display:flex;align-items:center;gap:10px;padding:7px 0;
                            border-bottom:.5px solid #f0f0ee">
                    <span style="font-size:10px;color:#888;min-width:36px">{ev['time']}</span>
                    <span style="width:8px;height:8px;border-radius:50%;
                                 background:{dot_color};display:inline-block;flex-shrink:0"></span>
                    <span style="font-size:11px">{ev['msg']}</span>
                </div>""", unsafe_allow_html=True)

        with tab_charts:
            st.markdown('<div class="sh" style="margin-top:8px">Avg delay by route</div>',
                        unsafe_allow_html=True)
            st.plotly_chart(fig_delay_bars(routes), use_container_width=True)
            st.markdown('<div class="sh">Disruptions — last 24 h</div>',
                        unsafe_allow_html=True)
            spark = [2,3,5,4,6,8,14,22,28,31,26,24,19,17,15,18,22,26,29,24,18,14,10,8]
            st.plotly_chart(fig_sparkline(spark), use_container_width=True)
            st.markdown('<div style="display:flex;justify-content:space-between;'
                        'font-size:9px;color:#888;margin-top:2px">'
                        '<span>00:00</span><span>06:00</span><span>12:00</span>'
                        '<span>18:00</span><span>now</span></div>',
                        unsafe_allow_html=True)

    # ── right sidebar ─────────────────────────────────────────────────────────
    with col_side:
        st.markdown('<div class="sh">Alert distribution</div>', unsafe_allow_html=True)
        alert_dist = {"Technical":43,"Weather":31,"Construction":16,"Other":10}
        st.plotly_chart(fig_donut(alert_dist), use_container_width=True)
        for label, pct, color in zip(
            alert_dist.keys(), alert_dist.values(),
            ["#E24B4A","#BA7517","#185FA5","#3B6D11"],
        ):
            st.markdown(
                f'<div style="font-size:10px;display:flex;align-items:center;'
                f'gap:6px;margin-bottom:3px">'
                f'<span style="width:8px;height:8px;border-radius:50%;'
                f'background:{color};display:inline-block"></span>'
                f'{label} ({pct}%)</div>',
                unsafe_allow_html=True,
            )

        st.markdown('<div class="sh" style="margin-top:14px">Route health</div>',
                    unsafe_allow_html=True)
        for r in routes[:5]:
            c = _delay_color(r["delay"])
            pred = min(r.get("pred", 0), 100)
            st.markdown(f"""
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
                <div style="font-size:11px;min-width:38px">{r['id']}</div>
                <div style="flex:1;height:4px;background:#eee;border-radius:2px">
                  <div style="height:4px;width:{pred:.0f}%;background:{c};border-radius:2px"></div>
                </div>
                <div style="font-size:11px;color:{c};min-width:40px;text-align:right">
                    {r['delay']:.1f}m</div>
            </div>""", unsafe_allow_html=True)

        st.markdown('<div class="sh" style="margin-top:14px">System status</div>',
                    unsafe_allow_html=True)
        statuses = [
            ("GTFS-RT Feed",  "Live",   "#2A7A4A"),
            ("ML Inference",  "145 ms", "#2A7A4A"),
            ("Static GTFS",   "Stale 4h","#B07010"),
            ("Data Quality",  "94.1%",  "#2A7A4A"),
            ("Leakage ctrl",  "Active", "#2A7A4A"),
        ]
        for name, val, color in statuses:
            st.markdown(f"""
            <div style="display:flex;justify-content:space-between;align-items:center;
                        padding:5px 0;border-bottom:.5px solid #f0f0ee;font-size:11px">
                <div style="display:flex;align-items:center;gap:6px">
                    <span style="width:7px;height:7px;border-radius:50%;
                                 background:{color};display:inline-block"></span>{name}
                </div>
                <span style="color:{color}">{val}</span>
            </div>""", unsafe_allow_html=True)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: LIVE MAP
# ══════════════════════════════════════════════════════════════════════════════

def page_map(vehicles_df: pd.DataFrame, routes: List[Dict]):
    st.markdown('<div class="sh">Live vehicle positions</div>', unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    route_counts = vehicles_df["route_id"].value_counts() if not vehicles_df.empty else pd.Series(dtype=int)
    c1.metric("Total vehicles",  len(vehicles_df))
    c2.metric("Critical routes", sum(1 for r in routes if r["status"] == "crit"))
    avg_spd = round(float(vehicles_df["speed"].mean()), 1) if "speed" in vehicles_df.columns and not vehicles_df.empty else 0.0
    c3.metric("Avg fleet speed", f"{avg_spd} km/h")
    c4.metric("Routes tracked",  len(route_counts))

    st.markdown("---")

    if FOLIUM_OK and not vehicles_df.empty:
        st.markdown('<div class="sh">Interactive map (Folium)</div>', unsafe_allow_html=True)
        m = _folium_map(vehicles_df.dropna(subset=["latitude","longitude"]))
        st_folium(m, use_container_width=True, height=400)
    else:
        if not FOLIUM_OK:
            st.info("Install `folium` and `streamlit-folium` for an interactive map.")
        st.markdown('<div class="sh">Vehicle positions (Plotly)</div>', unsafe_allow_html=True)
        st.plotly_chart(fig_vehicle_map_plotly(vehicles_df), use_container_width=True)

    st.markdown("---")
    st.markdown('<div class="sh">Delay hotspots by route</div>', unsafe_allow_html=True)
    st.plotly_chart(fig_delay_bars(routes), use_container_width=True)

    # Per-route vehicle count table
    if not route_counts.empty:
        st.markdown('<div class="sh" style="margin-top:1rem">Vehicles per route</div>',
                    unsafe_allow_html=True)
        rc_df = route_counts.reset_index()
        rc_df.columns = ["Route", "Vehicles"]
        st.dataframe(rc_df, use_container_width=True, hide_index=True, height=220)


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: PREDICTIONS
# ══════════════════════════════════════════════════════════════════════════════

def page_predictions(routes: List[Dict], model_name: str):
    st.markdown('<div class="sh">ML disruption forecast — next 30 minutes</div>',
                unsafe_allow_html=True)

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Active model",   model_name)
    c2.metric("F1 score",       "0.87")
    c3.metric("Precision",      "0.88")
    c4.metric("Lead time avg",  "18 min")

    st.markdown("---")

    # Sorted predictions
    preds = sorted(routes, key=lambda r: r.get("pred", 0), reverse=True)
    for r in preds:
        prob  = r.get("pred", 0)
        color = _prob_color(prob)
        badge = ("badge-crit" if r["status"]=="crit"
                 else "badge-warn" if r["status"]=="delay"
                 else "badge-ok")
        status_txt = ("Critical" if r["status"]=="crit"
                      else "Delayed" if r["status"]=="delay"
                      else "On-time")
        st.markdown(f"""
        <div style="display:flex;align-items:center;gap:12px;padding:12px;
                    border:.5px solid #e8e8e4;border-left:4px solid {color};
                    border-radius:4px;margin-bottom:8px">
            <div style="flex:1">
                <div style="font-weight:500;font-size:13px">{r['id']} — {r['name']}</div>
                <div style="font-size:10px;color:#888;margin-top:2px">
                    Delay {r['delay']:.1f} min · Bunching {r['bunch']*100:.0f}%
                    · Throughput {r['throughput']} veh/hr
                </div>
                <div style="height:4px;background:#eee;border-radius:2px;margin-top:6px;width:220px">
                    <div style="height:4px;width:{prob:.0f}%;background:{color};
                                border-radius:2px"></div>
                </div>
            </div>
            <div style="text-align:right">
                <div style="font-family:Syne,sans-serif;font-weight:800;
                            font-size:26px;color:{color}">{prob:.0f}%</div>
                <span class="badge {badge}">{status_txt}</span>
            </div>
        </div>""", unsafe_allow_html=True)

    # ── SHAP panel ────────────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown('<div class="sh">SHAP feature importance (TreeExplainer)</div>',
                unsafe_allow_html=True)

    shap_col, info_col = st.columns([3, 1])
    with shap_col:
        route_ids    = [r["id"] for r in routes]
        selected_rid = st.selectbox("Analyse route", route_ids, key="shap_sel")
    with info_col:
        n_bg = st.slider("Background samples", 10, 200, 50, 10, key="shap_nbg")

    if selected_rid:
        with st.spinner(f"Computing SHAP values for {selected_rid}…"):
            # Invalidate cache if n_bg changed by using a cache-key that includes it
            @st.cache_data(ttl=60)
            def _shap(rid, nbg):
                data = _get(f"/shap/{rid}?n_background={nbg}")
                return data.get("contributions", _fallback_shap()) if data else _fallback_shap()
            contrib = _shap(selected_rid, n_bg)

        chart_col, top_col = st.columns([3, 1])
        with chart_col:
            st.plotly_chart(fig_shap(contrib), use_container_width=True)
        with top_col:
            st.markdown('<div class="sh">Top 3 drivers</div>', unsafe_allow_html=True)
            for feat, val in sorted(contrib.items(), key=lambda x: x[1], reverse=True)[:3]:
                st.markdown(
                    f'<div style="font-size:11px;margin-bottom:8px">'
                    f'<strong>{feat}</strong><br>'
                    f'<span style="color:#C84040;font-family:Syne,sans-serif;'
                    f'font-weight:700">{val:.4f}</span></div>',
                    unsafe_allow_html=True,
                )

    # ── Model comparison ──────────────────────────────────────────────────────
    st.markdown("---")
    st.markdown('<div class="sh">Model comparison</div>', unsafe_allow_html=True)
    model_df = pd.DataFrame({
        "Model":     ["RandomForest","XGBoost","LightGBM","Neural Net","Ensemble"],
        "F1":        [0.87, 0.85, 0.88, 0.79, 0.90],
        "Precision": [0.89, 0.88, 0.90, 0.81, 0.92],
        "Recall":    [0.85, 0.82, 0.86, 0.77, 0.88],
        "ROC-AUC":   [0.93, 0.92, 0.94, 0.86, 0.96],
    })
    st.dataframe(
        model_df.style.highlight_max(
            subset=["F1","Precision","Recall","ROC-AUC"], color="#EAF3DE"
        ).format({"F1":"{:.2f}","Precision":"{:.2f}","Recall":"{:.2f}","ROC-AUC":"{:.2f}"}),
        use_container_width=True, hide_index=True,
    )


# ══════════════════════════════════════════════════════════════════════════════
# PAGE: ANALYTICS
# ══════════════════════════════════════════════════════════════════════════════

def page_analytics(routes: List[Dict], metrics: Dict):
    st.markdown('<div class="sh">Historical performance & budget (MTD)</div>',
                unsafe_allow_html=True)

    # 24-h trend
    spark  = [2,3,5,4,6,8,14,22,28,31,26,24,19,17,15,18,22,26,29,24,18,14,10,8]
    hours  = pd.date_range(end=datetime.now(), periods=24, freq="h")
    st.markdown('<div class="sh">Disruptions — 24 h rolling</div>', unsafe_allow_html=True)
    st.plotly_chart(fig_trend(hours, spark), use_container_width=True)

    # Route delay chart
    st.markdown('<div class="sh" style="margin-top:.6rem">Average delay by route</div>',
                unsafe_allow_html=True)
    st.plotly_chart(fig_delay_bars(routes), use_container_width=True)

    # Budget vs actuals
    st.markdown("---")
    st.markdown('<div class="sh">Budget vs actuals (MTD)</div>', unsafe_allow_html=True)
    budget_rows = [
        ("Cancellations",  15000,  9300),
        ("Major delays",    8000,  3600),
        ("Minor delays",    3000,  1200),
        ("Maintenance",    12000,  3400),
        ("Technical",       8000,   800),
    ]
    bdf = pd.DataFrame(budget_rows, columns=["Category","Budget (€)","Actual (€)"])
    bdf["Variance (€)"] = bdf["Budget (€)"] - bdf["Actual (€)"]
    bdf["Variance %"]   = (bdf["Variance (€)"] / bdf["Budget (€)"] * 100).round(1)
    total = pd.DataFrame([{
        "Category":    "TOTAL",
        "Budget (€)":  bdf["Budget (€)"].sum(),
        "Actual (€)":  bdf["Actual (€)"].sum(),
        "Variance (€)":bdf["Variance (€)"].sum(),
        "Variance %":  round(bdf["Variance (€)"].sum() / bdf["Budget (€)"].sum() * 100, 1),
    }])
    display = pd.concat([bdf, total], ignore_index=True)

    def _style_v(v):
        return "color:#2A7A4A;font-weight:500" if v > 0 else "color:#C84040;font-weight:500"

    st.dataframe(
        display.style
            .applymap(_style_v, subset=["Variance (€)","Variance %"])
            .format({"Budget (€)":"€{:,.0f}","Actual (€)":"€{:,.0f}",
                     "Variance (€)":"€{:+,.0f}","Variance %":"{:+.1f}%"}),
        use_container_width=True, hide_index=True,
    )

    # Period summary
    st.markdown("---")
    st.markdown('<div class="sh">Period summary</div>', unsafe_allow_html=True)
    k1,k2,k3,k4 = st.columns(4)
    k1.metric("Total routes",    len(routes))
    k2.metric("Avg delay",       f"{metrics.get('avg_delay_min',8.2):.1f} min")
    k3.metric("On-time %",       f"{metrics.get('on_time_pct',88.2):.1f}%")
    k4.metric("Data quality",    f"{metrics.get('data_quality_score',94.1):.1f}%")

    # Lead-time analysis
    st.markdown("---")
    st.markdown('<div class="sh">Early warning lead-time distribution</div>',
                unsafe_allow_html=True)
    rng = np.random.default_rng(42)
    lt  = rng.exponential(15, 1000)
    fig = px.histogram(x=lt, nbins=30,
                       labels={"x":"Lead time (min)","y":"Count"},
                       color_discrete_sequence=["#1A5FA0"],
                       template="none")
    fig.add_vline(x=15, line_dash="dash", line_color="#C84040",
                  annotation_text="15 min target",
                  annotation_font_color="#C84040", annotation_font_size=10)
    fig.update_layout(**_base_layout(height=200, showlegend=False),
                      xaxis=dict(showgrid=False), yaxis=dict(showgrid=False))
    lc, rc = st.columns([3, 1])
    with lc:
        st.plotly_chart(fig, use_container_width=True)
    with rc:
        st.markdown("""
        | Metric | Value |
        |--------|-------|
        | Mean   | 15.2 min |
        | Median | 12.8 min |
        | Std    |  8.4 min |
        | > 15 min | 42 % |
        """)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def main():
    # ── data ──────────────────────────────────────────────────────────────────
    api_ok     = _api_online()
    model_name = _active_model() if api_ok else "simulation"

    with st.spinner("Loading…"):
        metrics     = fetch_metrics()
        routes      = fetch_routes()
        alerts      = fetch_alerts()
        vehicles_df = fetch_vehicles()

    # ── sidebar + nav ─────────────────────────────────────────────────────────
    opts = render_sidebar(api_ok, model_name, metrics)

    # ── topbar ────────────────────────────────────────────────────────────────
    render_topbar(api_ok, model_name)

    # ── KPI row ───────────────────────────────────────────────────────────────
    render_kpi_row(metrics)

    # ── page ──────────────────────────────────────────────────────────────────
    page = opts["page"]
    if   page == "Overview":    page_overview(routes, alerts, metrics, opts)
    elif page == "Live Map":    page_map(vehicles_df, routes)
    elif page == "Predictions": page_predictions(routes, model_name)
    elif page == "Analytics":   page_analytics(routes, metrics)


if __name__ == "__main__":
    main()
